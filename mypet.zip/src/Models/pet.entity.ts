import { Column, Entity, ManyToOne, OneToMany, PrimaryGeneratedColumn } from "typeorm";
import { Photo } from "./photo.entity";
import { Shelter } from "./shelter.entity";
import { User } from "./user.entity";

@Entity()
export class Pet {
    @PrimaryGeneratedColumn('increment')
    id: number;

    @Column()
    name: string;

    @Column()
    type: string;

    @Column()
    age: number;

    @Column()
    gender:string;

    @ManyToOne(() => Shelter, shelter => shelter.pets)
    shelter: Shelter;

    @OneToMany(() => Photo, photo => photo.pet)
    photos: Photo[];

    @ManyToOne(() => User, user => user.pets, {nullable: false})
    user: User;
}                                                                                                                                                                                                                                                                        